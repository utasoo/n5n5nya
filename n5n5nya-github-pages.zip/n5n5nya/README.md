# 🌸 JLPT N5 한자·단어 마스터

파스텔 핑크 테마의 JLPT N5 학습 사이트입니다.

## 포함된 기능
- N5 한자·단어 목록과 검색 및 카테고리 필터
- 학습 진도 및 암기 상태
- 한자·단어 손글씨 연습
- 객관식 퀴즈와 오답 노트
- 손글씨 받아쓰기 시험 및 자동 채점

## GitHub Pages 배포 방법
1. GitHub에서 `n5n5nya`라는 이름으로 **Public** 저장소를 만듭니다.
2. 이 폴더 안의 `index.html`과 `README.md`를 저장소 최상위(root)에 업로드합니다.
3. 저장소의 **Settings → Pages**로 이동합니다.
4. **Deploy from a branch**를 선택합니다.
5. Branch를 `main`, 폴더를 `/(root)`로 지정하고 **Save**를 누릅니다.
6. 잠시 기다리면 아래 주소에서 사이트를 확인할 수 있습니다.

https://utasoo.github.io/n5n5nya/

## 참고
- Tailwind CSS와 Google Fonts를 CDN으로 불러오므로 첫 접속 시 인터넷 연결이 필요합니다.
- 학습 기록은 현재 브라우저의 로컬 저장소에 저장됩니다. 다른 기기나 브라우저와 자동 동기화되지는 않습니다.
